# Skin Blue Twilight by heppen
Simple. Lightweight. Elegant. That's all you need to enjoy Kodi.

# Installation & Updates

_You can install it via repository to provide automatic updates_

- Download repository: [repository.heppen](https://github.com/heppen7/repository.heppen/raw/main/repository.heppen.zip)
- Or install it via Kodi file-manager
  - add source: https://heppen7.github.io/ or https://zips.ovh/heppen

_or install it manually (updates should be installed manually)_

- [skin.blue.twilight](https://github.com/heppen7/skin.blue.twilight/archive/refs/heads/master.zip)
