# Mods of Skin Arctic Zephyr 2
*This skin is created by jurialmunkey, moded by pkscout to work with Kodi 19 Matrix and contains edits by me, heppen :)*

# Dependencies
*To make it fully working you have to install some dependencies in this order.*

1. https://github.com/kodi-community-addons/script.module.thetvdb/archive/refs/heads/master.zip
2. https://github.com/kodi-community-addons/script.module.musicbrainz/archive/refs/heads/master.zip
3. https://github.com/kodi-community-addons/script.module.metadatautils/archive/refs/heads/master.zip
4. https://github.com/kodi-community-addons/script.module.cherrypy/archive/refs/heads/master.zip
5. https://github.com/kodi-community-addons/script.skin.helper.service/archive/refs/heads/master.zip
6. https://github.com/kodi-community-addons/script.skin.helper.widgets/archive/refs/heads/master.zip
7. https://github.com/kodi-community-addons/script.skin.helper.skinbackup/archive/refs/heads/master.zip

# License

*This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 4.0 Unported License.
To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/4.0/
or send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.*