# Mods of Skin Arctic Zephyr 2
*This skin is created by jurialmunkey, moded by pkscout to work with Kodi 19 Matrix and contains edits by me, heppen :)*

# Installation & Updates

*You can install it via repository to provide automatic updates*
- Download repository: [repository.heppen](https://github.com/nfm886/repository.heppen/raw/main/repository.heppen.zip)
- Or install it via Kodi file-manager
	- add source: https://nfm886.github.io/repository.heppen

*or install it manually (updates should be installed manually)*
- [skin.arctic.zephyr.2.heppen.mod](https://github.com/nfm886/skin.arctic.zephyr.2.heppen.mod/archive/refs/heads/main.zip)

# License

*This work is licensed under the Creative Commons Attribution-NonCommercial-ShareAlike 4.0 Unported License.
To view a copy of this license, visit http://creativecommons.org/licenses/by-nc-sa/4.0/
or send a letter to Creative Commons, 171 Second Street, Suite 300, San Francisco, California, 94105, USA.*