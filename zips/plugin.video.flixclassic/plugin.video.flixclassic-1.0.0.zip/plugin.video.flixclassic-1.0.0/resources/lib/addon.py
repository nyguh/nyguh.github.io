import sys
import routing
import requests

from .helper import Helper

base_url = sys.argv[0]
handle = int(sys.argv[1])
helper = Helper(base_url, handle)
plugin = routing.Plugin()


@plugin.route('/')
def root():
    if not helper.user_logged_in():
        helper.add_item('Zaloguj', plugin.url_for(login))
        helper.add_item('Ustawienia', plugin.url_for(open_settings))
        helper.eod(cache=False)
    else:
        helper.add_item('Filmy', plugin.url_for(movies))
        helper.add_item('Seriale', plugin.url_for(series))
        helper.add_item('Żelazny kanon', plugin.url_for(products, 7864))
        helper.add_item('Zapomniane perełki', plugin.url_for(products, 7865))
        helper.add_item('Swobodna jazda', plugin.url_for(products, 7867))
        helper.add_item('Gaz do dechy', plugin.url_for(products, 7866))
        helper.add_item('Ulubione', plugin.url_for(favorites))
        helper.add_item('Moja lista', plugin.url_for(my_list))
        helper.add_item('Ustawienia', plugin.url_for(open_settings))
        helper.add_item('Wyloguj', plugin.url_for(logout))
        helper.eod(cache=False)


@plugin.route('/login')
def login():
    helper.user_login()


@plugin.route('/logout')
def logout():
    helper.user_logout()


@plugin.route('/settings')
def open_settings():
    helper.open_settings()


@plugin.route('/movies')
def movies():
    endpoint = '/api/products/sections/movies'
    url = f'https://{helper.host}{endpoint}'
    params = {
        'elementsLimit': 10,
        'lang': 'pl',
        'platform': 'BROWSER'
    }
    helper.headers.update({'Cookie': helper.cookies})
    response = helper.make_request(url, 'get', params=params, headers=helper.headers)

    for item in response:
        if item['type'] == 'SECTION' and item['contentType'] != 'CATALOG':
            section_id = item['id']
            section_title = item['title']
            images = None
            if item['images']:
                image_url = 'https:' + item['images']['16x9'][0]['url']
                images = {
                    'icon': image_url,
                    'fanart': image_url
                }
            info_label = {
                'title': section_title
            }
            helper.add_item(section_title, plugin.url_for(products, section_id), info=info_label, art=images)
        elif item['type'] == 'SECTION' and item['contentType'] == 'CATALOG':
            section_title = item['title']
            info_label = {
                'title': section_title
            }
            helper.add_item(section_title, plugin.url_for(catalog, main_cat_id=1), info=info_label)
    helper.add_item('FILMY - KATEGORIE', plugin.url_for(movies_categories))

    helper.eod()


@plugin.route('/series')
def series():
    endpoint = '/api/products/sections/series'
    url = f'https://{helper.host}{endpoint}'
    params = {
        'elementsLimit': 10,
        'lang': 'pl',
        'platform': 'BROWSER'
    }
    helper.headers.update({'Cookie': helper.cookies})
    response = helper.make_request(url, 'get', params=params, headers=helper.headers)

    for item in response:
        if item['type'] == 'SECTION' and item['contentType'] != 'CATALOG':
            section_id = item['id']
            section_title = item['title']
            images = None
            if item['images']:
                image_url = 'https:' + item['images']['16x9'][0]['url']
                images = {
                    'icon': image_url,
                    'fanart': image_url
                }
            info_label = {
                'title': section_title
            }
            helper.add_item(section_title, plugin.url_for(products, section_id), info=info_label, art=images)
        elif item['type'] == 'SECTION' and item['contentType'] == 'CATALOG':
            section_title = item['title']
            info_label = {
                'title': section_title
            }
            helper.add_item(section_title, plugin.url_for(catalog, main_cat_id=2), info=info_label)
    helper.add_item('SERIALE - KATEGORIE', plugin.url_for(series_categories))

    helper.eod()


@plugin.route('/series_categories')
def series_categories():
    endpoint = '/api/items/categories'
    url = f'https://{helper.host}{endpoint}'
    params = {
        'mainCategoryId': 2,
        'lang': 'pl',
        'platform': 'BROWSER'
    }
    helper.headers.update({'Cookie': helper.cookies})
    response = helper.make_request(url, 'get', params=params, headers=helper.headers)

    if response:
        for category in response:
            category_id = category['id']
            category_name = category['name']

            helper.add_item(category_name, plugin.url_for(catalog, main_cat_id=2, cat_id=category_id))

    helper.eod()


@plugin.route('/movies_categories')
def movies_categories():
    endpoint = '/api/items/categories'
    url = f'https://{helper.host}{endpoint}'
    params = {
        'mainCategoryId': 1,
        'lang': 'pl',
        'platform': 'BROWSER'
    }
    helper.headers.update({'Cookie': helper.cookies})
    response = helper.make_request(url, 'get', params=params, headers=helper.headers)

    if response:
        for category in response:
            category_id = category['id']
            category_name = category['name']

            helper.add_item(category_name, plugin.url_for(catalog, main_cat_id=1, cat_id=category_id))

    helper.eod()


@plugin.route('/catalog')
def catalog():
    elements_type = None
    endpoint = '/api/products/vods'
    url = f'https://{helper.host}{endpoint}'
    if plugin.args.get('cat_id'):
        params = {
            'firstResult': 0,
            'maxResults': 1000,
            'mainCategoryId[]': plugin.args['main_cat_id'],
            'categoryId[]': plugin.args['cat_id'],
            'lang': 'pl',
            'platform': 'BROWSER'
        }
    else:
        params = {
            'firstResult': 0,
            'maxResults': 1000,
            'mainCategoryId[]': plugin.args['main_cat_id'],
            'lang': 'pl',
            'platform': 'BROWSER'
        }
    if plugin.args['main_cat_id']:
        if int(plugin.args['main_cat_id'][0]) == 1:
            elements_type = 'movies'
        elif int(plugin.args['main_cat_id'][0]) == 2:
            elements_type = 'series'

    helper.headers.update({'Cookie': helper.cookies})
    response = helper.make_request(url, 'get', params=params, headers=helper.headers)

    for elements in response['items']:
        element_id = elements['id']
        element_title = elements['title']
        element_lead = elements['lead']
        images = None
        if elements['images']:
            image_url = 'https:' + elements['images']['3x4'][0]['url']
            fanart_url = 'https:' + elements['images']['16x9'][0]['url']
            images = {
                'icon': image_url,
                'fanart': fanart_url
            }
        info_label = {
            'title': element_title,
            'plot': element_lead
        }
        helper.add_item(element_title, plugin.url_for(element, id=element_id, title=element_title, type=elements_type),
                        info=info_label, art=images)

    helper.eod()


@plugin.route('/products/<section_id>')
def products(section_id):
    endpoint = '/api/products/sections/' + section_id
    url = f'https://{helper.host}{endpoint}'
    params = {
        'elementsLimit': 10,
        'lang': 'pl',
        'platform': 'BROWSER'
    }
    helper.headers.update({'Cookie': helper.cookies})
    response = helper.make_request(url, 'get', params=params, headers=helper.headers)

    for elements in response['elements']:
        element_id = elements['item']['id']
        element_title = elements['item']['title']
        element_lead = elements['item']['lead']
        images = None
        if elements['item']['images']:
            image_url = 'https:' + elements['item']['images']['3x4'][0]['url']
            fanart_url = 'https:' + elements['item']['images']['16x9'][0]['url']
            images = {
                'icon': image_url,
                'fanart': fanart_url
            }
        info_label = {
            'title': element_title,
            'plot': element_lead
        }
        helper.add_item(element_title, plugin.url_for(element, id=element_id, title=element_title, type='movies'),
                        info=info_label, art=images)

    helper.eod()


@plugin.route('/element/<id>/<title>/<type>')
def element(id, title, type):
    if type == 'movies':
        endpoint = '/api/products/vods/' + id
        url = f'https://{helper.host}{endpoint}'
        params = {
            'lang': 'pl',
            'platform': 'BROWSER'
        }
        helper.headers.update({'Cookie': helper.cookies})
        response = helper.make_request(url, 'get', params=params, headers=helper.headers)

        info_label = {
            'title': title,
            'plotoutline': response['lead'],
            'plot': response['description'].replace('<p>', '').replace('</p>', '')
        }

        images = {
            'icon': 'https:' + response['images']['3x4'][0]['url'],
            'poster': 'https:' + response['images']['3x4'][0]['url'],
            'fanart': 'https:' + response['images']['16x9'][0]['url']
        }

        helper.add_item('OGLĄDAJ - ' + title, plugin.url_for(configuration, id), playable=True, info=info_label,
                        art=images)

        if helper.is_favorite(id):
            helper.add_item('USUŃ Z ULUBIONYCH', plugin.url_for(remove_bookmark, id))
        else:
            helper.add_item('DODAJ DO ULUBIONYCH', plugin.url_for(add_bookmark, id))

        helper.eod()

    elif type == 'series':
        endpoint = f'/api/products/vods/serials/{id}/seasons'
        url = f'https://{helper.host}{endpoint}'
        params = {
            'lang': 'pl',
            'platform': 'BROWSER'
        }
        helper.headers.update({'Cookie': helper.cookies})
        response = helper.make_request(url, 'get', params=params, headers=helper.headers)

        if response:
            for season in response:
                season_id = season['id']
                season_title = season['title']

                helper.add_item(season_title, plugin.url_for(episodes, id=id, season_id=season_id))

                if helper.is_favorite(id):
                    helper.add_item('USUŃ Z ULUBIONYCH', plugin.url_for(remove_bookmark, id))
                else:
                    helper.add_item('DODAJ DO ULUBIONYCH', plugin.url_for(add_bookmark, id))

                helper.eod()


@plugin.route('/episodes/<id>/<season_id>')
def episodes(id, season_id):
    endpoint = f'/api/products/vods/serials/{id}/seasons/{season_id}/episodes'
    url = f'https://{helper.host}{endpoint}'
    params = {
        'lang': 'pl',
        'platform': 'BROWSER'
    }
    helper.headers.update({'Cookie': helper.cookies})
    response = helper.make_request(url, 'get', params=params, headers=helper.headers)

    if response:
        for episode in response:
            episode_id = episode['id']
            episode_title = episode['title']

            info_label = {
                'title': episode_title,
            }

            images = {
                'icon': 'https:' + episode['images']['3x4'][0]['url'],
                'poster': 'https:' + episode['images']['3x4'][0]['url'],
                'fanart': 'https:' + episode['images']['16x9'][0]['url']
            }

            helper.add_item(episode_title, plugin.url_for(configuration, episode_id), playable=True, info=info_label,
                            art=images)

    helper.eod()


@plugin.route('/configuration/<configuration_id>')
def configuration(configuration_id):
    endpoint = f'/api/products/{configuration_id}/videos/player/configuration'
    url = f'https://{helper.host}{endpoint}'
    params = {
        'lang': 'pl',
        'platform': 'BROWSER',
        'videoType': 'MOVIE'
    }
    helper.headers.update({'Cookie': helper.cookies})
    response = helper.make_request(url, 'get', params=params, headers=helper.headers)

    if helper.video_session:
        delete_url = f'https://{helper.host}/api/products/videosessions/{helper.video_session}'
        requests.delete(delete_url)

    if response['videoSession']:
        helper.set_setting('video_session', response['videoSession']['videoSessionId'])

        product_playlist(configuration_id)


def product_playlist(configuration_id):
    endpoint = f'/api/products/{configuration_id}/videos/playlist'
    url = f'https://{helper.host}{endpoint}'
    params = {
        'platform': 'BROWSER',
        'videoType': 'MOVIE'
    }
    helper.headers.update({'Cookie': helper.cookies})
    response = helper.make_request(url, 'get', params=params, headers=helper.headers)

    if response:
        license_url = response['drm'].get('WIDEVINE')['src']
        stream_url = response['sources']['DASH'][0]['src']
        stream_url = 'https:' + stream_url if stream_url.startswith('//') else stream_url
        stream_url = helper.make_request(stream_url, method='get', allow_redirects=True, verify=False, json=False)
        stream_url = stream_url.url

        if license_url:
            drm_protocol = 'mpd'
            drm = 'com.widevine.alpha'

            helper.play_video(stream_url=stream_url, drm_protocol=drm_protocol, drm=drm, license_url=license_url)


@plugin.route('/my_list')
def my_list():
    helper.add_item('Kontynuuj oglądanie', plugin.url_for(watched))
    helper.eod()


@plugin.route('/favorites')
def favorites():
    for bookmark in helper.cookies.split(';'):
        if 'cache_bookmark_favourite=' in bookmark:
            bookmark_id = bookmark.split('=')[len(bookmark.split('=')) - 1]

            endpoint = f'/api/subscribers/bookmarks'
            url = f'https://{helper.host}{endpoint}'
            params = {
                'type': 'FAVOURITE',
                'lang': 'pl',
                'platform': 'BROWSER',
                'hash': bookmark_id
            }
            helper.headers.update({'Cookie': helper.cookies})
            response = helper.make_request(url, 'get', params=params, headers=helper.headers)

            if response:
                if len(response['items']) > 0:
                    for item in response['items']:
                        item_id = item['item']['id']
                        item_title = item['item']['title']
                        item_slug = item['item']['mainCategory']['slug']
                        images = None
                        if item['item']['images']:
                            image_url = 'https:' + item['item']['images']['3x4'][0]['url']
                            images = {
                                'icon': image_url,
                                'fanart': image_url
                            }
                        info_label = {
                            'title': item_title
                        }
                        helper.add_item(item_title,
                                        plugin.url_for(element, id=item_id, title=item_title, type=item_slug),
                                        info=info_label, art=images)
                else:
                    helper.add_item('Pusto', plugin.url_for(root))

            helper.eod()


@plugin.route('/add_bookmark/<id>')
def add_bookmark(id):
    endpoint = '/api/subscribers/bookmarks'
    url = f'https://{helper.host}{endpoint}'
    payload = {"itemId": id}
    params = {
        'type': 'FAVOURITE',
        'lang': 'pl',
        'platform': 'BROWSER'
    }
    helper.headers.update({'Cookie': helper.cookies})
    helper.make_request(url, 'post', params=params, payload=payload, headers=helper.headers, json=False)

    helper.notification('Informacja', 'Dodano do ulubionych.')


@plugin.route('/remove_bookmark/<id>')
def remove_bookmark(id):
    endpoint = '/api/subscribers/bookmarks'
    url = f'https://{helper.host}{endpoint}'
    params = {
        'type': 'FAVOURITE',
        'itemId[]': id,
        'lang': 'pl',
        'platform': 'BROWSER'
    }
    helper.headers.update({'Cookie': helper.cookies})
    requests.delete(url, params=params, headers=helper.headers)

    helper.notification('Informacja', 'Usunięto z ulubionych.')


@plugin.route('/watched')
def watched():
    for bookmark in helper.cookies.split(';'):
        if 'cache_bookmark_watched=' in bookmark:
            bookmark_id = bookmark.split('=')[len(bookmark.split('=')) - 1]

            endpoint = f'/api/subscribers/bookmarks'
            url = f'https://{helper.host}{endpoint}'
            params = {
                'type': 'WATCHED',
                'lang': 'pl',
                'platform': 'BROWSER',
                'hash': bookmark_id
            }
            helper.headers.update({'Cookie': helper.cookies})
            response = helper.make_request(url, 'get', params=params, headers=helper.headers)

            if response:
                if len(response['items']) > 0:
                    for item in response['items']:
                        item_id = item['item']['id']
                        item_title = item['item']['title']
                        images = None
                        if item['item']['images']:
                            image_url = 'https:' + item['item']['images']['3x4'][0]['url']
                            images = {
                                'icon': image_url,
                                'fanart': image_url
                            }
                        info_label = {
                            'title': item_title
                        }
                        helper.add_item(item_title,
                                        plugin.url_for(element, id=item_id, title=item_title, type='movies'),
                                        info=info_label, art=images)
                else:
                    helper.add_item('Pusto', plugin.url_for(root))

            helper.eod()


class Addon(Helper):
    def __init__(self):
        super().__init__()
        self.log(sys.argv)
        plugin.run()
