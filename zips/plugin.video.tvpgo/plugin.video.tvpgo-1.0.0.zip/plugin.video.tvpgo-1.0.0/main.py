from resources.lib.addon import Addon

if __name__ == '__main__':
    Addon()
