import uuid
import requests

import xbmc
import xbmcgui
import xbmcvfs
import xbmcaddon
import xbmcplugin


class Helper:
    def __init__(self, base_url=None, handle=None):
        self.base_url = base_url
        self.handle = handle
        self.addon = xbmcaddon.Addon()
        self.addon_name = self.addon.getAddonInfo('id')
        self.addon_version = self.addon.getAddonInfo('version')
        self.logging_prefix = f'===== [{self.addon_name} - {self.addon_version}] ====='
        self.http_session = requests.Session()
        # User data
        self.user_name = self.get_setting('username')
        self.user_password = self.get_setting('password')
        try:
            self.token = self.get_setting('token')
            self.uuid = self.get_setting('uuid')
            self.cookies = self.get_setting('cookies')
            self.user_id = self.get_setting('id')
        except TypeError:
            self.token = self.set_setting('token', '')
            self.uuid = self.create_device_id()
            self.cookies = self.set_setting('cookies', '')
            self.user_id = self.set_setting('id', '0')
        try:
            self.video_session = self.get_setting('video_session')
        except TypeError:
            self.video_session = self.set_setting('video_session', '')
        # API
        self.host = 'flixclassic.pl'
        self.user_agent = 'Mozilla/5.0 (X11; Linux x86_64; rv:99.0) Gecko/20100101 Firefox/99.0'
        self.headers = {
            'Host': self.host,
            'User-Agent': self.user_agent,
            'Accept': 'application/json, text/plain, */*',
            'Accept-Language': 'pl',
            'Accept-Encoding': 'gzip, deflate, br',
            'Content-Type': 'application/json;charset=utf-8',
            'API-DeviceUid': self.uuid,
            'Origin': f'https://{self.host}',
            'Connection': 'keep-alive',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-origin',
            'TE': 'trailers'
        }

    def log(self, string):
        msg = f'{self.logging_prefix}: {string}'
        xbmc.log(msg=msg, level=1)

    def get_setting(self, string):
        return xbmcaddon.Addon(self.addon_name).getSettingString(string)

    def set_setting(self, setting, string):
        return xbmcaddon.Addon(self.addon_name).setSettingString(id=setting, value=string)

    def open_settings(self):
        xbmcaddon.Addon(self.addon_name).openSettings()

    def add_item(self, title, url, playable=False, info=None, art=None, content=None, folder=True):
        list_item = xbmcgui.ListItem(label=title)
        if playable:
            list_item.setProperty('IsPlayable', 'true')
            folder = False
        if art:
            list_item.setArt(art)
        else:
            art = {
                'icon': self.addon.getAddonInfo('icon'),
                'fanart': self.addon.getAddonInfo('fanart')
            }
            list_item.setArt(art)
        if info:
            list_item.setInfo('Video', info)
        if content:
            xbmcplugin.setContent(self.handle, content)

        xbmcplugin.addDirectoryItem(self.handle, url, list_item, isFolder=folder)

    def eod(self, cache=True):
        xbmcplugin.endOfDirectory(self.handle, cacheToDisc=cache)

    def notification(self, heading, message):
        xbmcgui.Dialog().notification(heading, message, time=7000)

    def create_device_id(self):
        dev_id = uuid.uuid1()
        return self.set_setting('uuid', str(dev_id))

    def make_request(self, url, method, params=None, payload=None, headers=None, allow_redirects=None, verify=None,
                     json=True):
        self.log(f'Request URL: {url}')
        self.log(f'Method: {method}')
        # if params:
        #     self.log(f'Params: {params}')
        # if payload:
        #     self.log(f'Payload: {payload}')
        # if headers:
        #     self.log(f'Headers: {headers}')

        if method == 'get':
            with self.http_session as req:
                if json:
                    return req.get(url, params=params, headers=headers, allow_redirects=allow_redirects,
                                   verify=verify).json()
                else:
                    return req.get(url, params=params, headers=headers, allow_redirects=allow_redirects, verify=verify)
        elif method == 'put':
            with self.http_session as req:
                if json:
                    return req.put(url, params=params, data=payload, headers=headers, verify=verify).json()
                else:
                    return req.put(url, params=params, data=payload, headers=headers, verify=verify)
        else:  # post
            with self.http_session as req:
                return req.post(url, params=params, json=payload, headers=headers)

    def user_logged_in(self):

        self.check_isa_settings()

        endpoint = '/api/subscribers/detail'
        url = f'https://{self.host}{endpoint}'
        params = {
            'lang': 'pl',
            'platform': 'BROWSER'
        }
        self.headers.update({'Cookie': self.cookies})

        response = self.make_request(url, 'get', params=params, headers=self.headers, json=True)
        if response.get('email'):
            return True
        else:
            self.user_login()

    def user_login(self):
        endpoint = '/api/subscribers/login'
        url = f'https://{self.host}{endpoint}'
        params = {
            'lang': 'pl',
            'platform': 'BROWSER'
        }
        payload = {
            "appVersion": "32b211b",
            "email": self.user_name,
            "auth": {
                "type": "PASSWORD",
                "value": self.user_password
            },
            "rememberMe": True
        }

        if self.user_name and self.user_password:
            response = self.make_request(url, 'post', params=params, payload=payload, headers=self.headers, json=False)
            json = response.json()
            if json.get('token'):
                cookies = response.headers["set-cookie"]
                self.set_setting('cookies', cookies)
                self.set_setting('token', json.get('token'))
                self.set_setting('id', str(json.get('id')))
                if json['status'].get('trialEnabled'):
                    self.set_setting('tral', 'True')
                else:
                    self.set_setting('tral', 'False')
                return True
        else:
            self.open_settings()

    def user_logout(self):
        endpoint = '/api/subscribers/logout'
        url = f'https://{self.host}{endpoint}'
        params = {
            'lang': 'pl',
            'platform': 'BROWSER'
        }
        self.headers.update({'Cookie': self.cookies})
        self.make_request(url, 'post', params=params, headers=self.headers, json=False)

        self.set_setting('cookies', '')
        return True

    def play_video(self, stream_url, drm_protocol, drm, license_url):
        from inputstreamhelper import Helper  # pylint: disable=import-outside-toplevel

        play_item = xbmcgui.ListItem(path=stream_url)
        if license_url:
            is_helper = Helper(drm_protocol, drm=drm)
            if is_helper.check_inputstream():
                play_item.setProperty('inputstream', is_helper.inputstream_addon)
                play_item.setMimeType('application/xml+dash')
                play_item.setProperty('inputstream.adaptive.max_bandwidth', '99999999')
                play_item.setProperty('inputstream.adaptive.manifest_type', drm_protocol)
                play_item.setProperty('inputstream.adaptive.license_type', drm)
                play_item.setProperty('inputstream.adaptive.license_key', license_url + '||R{SSM}|')
                play_item.setContentLookup(False)
                xbmcplugin.setResolvedUrl(self.handle, True, listitem=play_item)

    def is_favorite(self, id):
        is_fav = False
        for bookmark in self.cookies.split(';'):
            if 'cache_bookmark_favourite=' in bookmark:
                bookmark_id = bookmark.split('=')[len(bookmark.split('=')) - 1]

                endpoint = f'/api/subscribers/bookmarks'
                url = f'https://{self.host}{endpoint}'
                params = {
                    'type': 'FAVOURITE',
                    'lang': 'pl',
                    'platform': 'BROWSER',
                    'hash': bookmark_id
                }
                self.headers.update({'Cookie': self.cookies})
                response = self.make_request(url, 'get', params=params, headers=self.headers)

                if response:
                    if len(response['items']) > 0:
                        for item in response['items']:
                            item_id = item['item']['id']
                            if int(item_id) == int(id):
                                is_fav = True

        return is_fav

    def check_isa_settings(self):
        ignore_display = xbmcaddon.Addon('inputstream.adaptive').getSetting('IGNOREDISPLAY')
        settings = [
            {
                'id': 'MINBANDWIDTH',
                'value': xbmcaddon.Addon('inputstream.adaptive').getSetting('MINBANDWIDTH')
            },
            {
                'id': 'MAXBANDWIDTH',
                'value': xbmcaddon.Addon('inputstream.adaptive').getSetting('MAXBANDWIDTH')
            },
            {
                'id': 'MAXRESOLUTION',
                'value': xbmcaddon.Addon('inputstream.adaptive').getSetting('MAXRESOLUTION')
            },
            {
                'id': 'MAXRESOLUTIONSECURE',
                'value': xbmcaddon.Addon('inputstream.adaptive').getSetting('MAXRESOLUTIONSECURE')
            },
            {
                'id': 'STREAMSELECTION',
                'value': xbmcaddon.Addon('inputstream.adaptive').getSetting('STREAMSELECTION')
            },
            {
                'id': 'MEDIATYPE',
                'value': xbmcaddon.Addon('inputstream.adaptive').getSetting('MEDIATYPE')
            }]

        for setting in settings:
            if setting['value'] != '0':
                xbmcaddon.Addon('inputstream.adaptive').setSetting(setting['id'], '0')

        if ignore_display != 'true':
            xbmcaddon.Addon('inputstream.adaptive').setSetting('IGNOREDISPLAY', 'true')

        return True
