#!/usr/bin/env python
from resources.lib.main import Main

if __name__ == '__main__':
    Main().run()
